# Czechoslovakia Bank Financial Data Analysis

# The Czechoslovakia Bank wants to analyse its financial data to gain insights and make informed decisions. The bank needs to identify trends, patterns, and potential risks in its financial operations. They also want to explore the possibility of introducing new financial products or services based on their analysis.


```python
#import the libraries to amnipulate the data
```


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
from datetime import date
```


```python
#import the data from the specified folder
accounts_df = pd.read_csv ('D:/credit/account.csv',sep=";")
cards_df = pd.read_csv ('D:/credit/card.csv', sep = ';')
clients_df = pd.read_csv ('D:/credit/client.csv', sep = ';')
dispos_df = pd.read_csv ('D:/credit/disp.csv', sep = ';')
district_df = pd.read_csv ('D:/credit/district.csv', sep = ';')
loan_df = pd.read_csv ('D:/credit/loan.csv', sep = ';')
order_df = pd.read_csv ('D:/credit/order.csv', sep = ';')
trans_df = pd.read_csv ('D:/credit/trans.csv', sep = ';')
```

    C:\Users\CB SUMANTH\AppData\Local\Temp\ipykernel_13792\4237979825.py:9: DtypeWarning: Columns (8) have mixed types. Specify dtype option on import or set low_memory=False.
      trans_df = pd.read_csv ('D:/credit/trans.csv', sep = ';')
    


```python
files = [accounts_df, cards_df, clients_df, dispos_df, district_df, loan_df, order_df, trans_df]
files_name = ['accounts_df', 'cards_df', 'clients_df', 'dispos_df', 'district_df', 'loan_df', 'order_df', 'trans_df']
```


```python
for id, item in enumerate (files): 
    print('Dataframe name: ' + str(files_name [id]) + " with number of rows:" + str(item.shape[0]) + ' and columns:' + str(item.shape[1]))
    display(item.describe())
    print(item.isnull().sum())
    print('\n')
```

    Dataframe name: accounts_df with number of rows:4500 and columns:4
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>account_id</th>
      <th>district_id</th>
      <th>date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>4500.000000</td>
      <td>4500.000000</td>
      <td>4500.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2786.067556</td>
      <td>37.310444</td>
      <td>951654.608667</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2313.811984</td>
      <td>25.177217</td>
      <td>14842.188377</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>930101.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1182.750000</td>
      <td>13.000000</td>
      <td>931227.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2368.000000</td>
      <td>38.000000</td>
      <td>960102.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>3552.250000</td>
      <td>60.000000</td>
      <td>961101.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>11382.000000</td>
      <td>77.000000</td>
      <td>971229.000000</td>
    </tr>
  </tbody>
</table>
</div>


    account_id     0
    district_id    0
    frequency      0
    date           0
    dtype: int64
    
    
    Dataframe name: cards_df with number of rows:892 and columns:4
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>card_id</th>
      <th>disp_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>892.000000</td>
      <td>892.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>480.855381</td>
      <td>3511.862108</td>
    </tr>
    <tr>
      <th>std</th>
      <td>306.933982</td>
      <td>2984.373626</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>9.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>229.750000</td>
      <td>1387.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>456.500000</td>
      <td>2938.500000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>684.250000</td>
      <td>4459.500000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1247.000000</td>
      <td>13660.000000</td>
    </tr>
  </tbody>
</table>
</div>


    card_id    0
    disp_id    0
    type       0
    issued     0
    dtype: int64
    
    
    Dataframe name: clients_df with number of rows:5369 and columns:3
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>client_id</th>
      <th>birth_number</th>
      <th>district_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>5369.000000</td>
      <td>5369.000000</td>
      <td>5369.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>3359.011920</td>
      <td>535114.970013</td>
      <td>37.310114</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2832.911984</td>
      <td>172895.618429</td>
      <td>25.043690</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>110820.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1418.000000</td>
      <td>406009.000000</td>
      <td>14.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2839.000000</td>
      <td>540829.000000</td>
      <td>38.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>4257.000000</td>
      <td>681013.000000</td>
      <td>60.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>13998.000000</td>
      <td>875927.000000</td>
      <td>77.000000</td>
    </tr>
  </tbody>
</table>
</div>


    client_id       0
    birth_number    0
    district_id     0
    dtype: int64
    
    
    Dataframe name: dispos_df with number of rows:5369 and columns:4
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>disp_id</th>
      <th>client_id</th>
      <th>account_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>5369.000000</td>
      <td>5369.000000</td>
      <td>5369.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>3337.097970</td>
      <td>3359.011920</td>
      <td>2767.496927</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2770.418826</td>
      <td>2832.911984</td>
      <td>2307.843630</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1418.000000</td>
      <td>1418.000000</td>
      <td>1178.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2839.000000</td>
      <td>2839.000000</td>
      <td>2349.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>4257.000000</td>
      <td>4257.000000</td>
      <td>3526.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>13690.000000</td>
      <td>13998.000000</td>
      <td>11382.000000</td>
    </tr>
  </tbody>
</table>
</div>


    disp_id       0
    client_id     0
    account_id    0
    type          0
    dtype: int64
    
    
    Dataframe name: district_df with number of rows:77 and columns:16
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A1</th>
      <th>A4</th>
      <th>A5</th>
      <th>A6</th>
      <th>A7</th>
      <th>A8</th>
      <th>A9</th>
      <th>A10</th>
      <th>A11</th>
      <th>A13</th>
      <th>A14</th>
      <th>A16</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>77.000000</td>
      <td>7.700000e+01</td>
      <td>77.000000</td>
      <td>77.000000</td>
      <td>77.000000</td>
      <td>77.000000</td>
      <td>77.000000</td>
      <td>77.000000</td>
      <td>77.000000</td>
      <td>77.000000</td>
      <td>77.000000</td>
      <td>77.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>39.000000</td>
      <td>1.338849e+05</td>
      <td>48.623377</td>
      <td>24.324675</td>
      <td>6.272727</td>
      <td>1.727273</td>
      <td>6.259740</td>
      <td>63.035065</td>
      <td>9031.675325</td>
      <td>3.787013</td>
      <td>116.129870</td>
      <td>5030.831169</td>
    </tr>
    <tr>
      <th>std</th>
      <td>22.371857</td>
      <td>1.369135e+05</td>
      <td>32.741829</td>
      <td>12.780991</td>
      <td>4.015222</td>
      <td>1.008338</td>
      <td>2.435497</td>
      <td>16.221727</td>
      <td>790.202347</td>
      <td>1.908480</td>
      <td>16.608773</td>
      <td>11270.796786</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>4.282100e+04</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>33.900000</td>
      <td>8110.000000</td>
      <td>0.430000</td>
      <td>81.000000</td>
      <td>888.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>20.000000</td>
      <td>8.585200e+04</td>
      <td>22.000000</td>
      <td>16.000000</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>5.000000</td>
      <td>51.900000</td>
      <td>8512.000000</td>
      <td>2.310000</td>
      <td>105.000000</td>
      <td>2122.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>39.000000</td>
      <td>1.088710e+05</td>
      <td>49.000000</td>
      <td>25.000000</td>
      <td>6.000000</td>
      <td>2.000000</td>
      <td>6.000000</td>
      <td>59.800000</td>
      <td>8814.000000</td>
      <td>3.600000</td>
      <td>113.000000</td>
      <td>3040.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>58.000000</td>
      <td>1.390120e+05</td>
      <td>71.000000</td>
      <td>32.000000</td>
      <td>8.000000</td>
      <td>2.000000</td>
      <td>8.000000</td>
      <td>73.500000</td>
      <td>9317.000000</td>
      <td>4.790000</td>
      <td>126.000000</td>
      <td>4595.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>77.000000</td>
      <td>1.204953e+06</td>
      <td>151.000000</td>
      <td>70.000000</td>
      <td>20.000000</td>
      <td>5.000000</td>
      <td>11.000000</td>
      <td>100.000000</td>
      <td>12541.000000</td>
      <td>9.400000</td>
      <td>167.000000</td>
      <td>99107.000000</td>
    </tr>
  </tbody>
</table>
</div>


    A1     0
    A2     0
    A3     0
    A4     0
    A5     0
    A6     0
    A7     0
    A8     0
    A9     0
    A10    0
    A11    0
    A12    0
    A13    0
    A14    0
    A15    0
    A16    0
    dtype: int64
    
    
    Dataframe name: loan_df with number of rows:682 and columns:7
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loan_id</th>
      <th>account_id</th>
      <th>date</th>
      <th>amount</th>
      <th>duration</th>
      <th>payments</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>682.000000</td>
      <td>682.000000</td>
      <td>682.000000</td>
      <td>682.000000</td>
      <td>682.000000</td>
      <td>682.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>6172.466276</td>
      <td>5824.162757</td>
      <td>963027.910557</td>
      <td>151410.175953</td>
      <td>36.492669</td>
      <td>4190.664223</td>
    </tr>
    <tr>
      <th>std</th>
      <td>682.579279</td>
      <td>3283.512681</td>
      <td>14616.406049</td>
      <td>113372.406310</td>
      <td>17.075219</td>
      <td>2215.830344</td>
    </tr>
    <tr>
      <th>min</th>
      <td>4959.000000</td>
      <td>2.000000</td>
      <td>930705.000000</td>
      <td>4980.000000</td>
      <td>12.000000</td>
      <td>304.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>5577.500000</td>
      <td>2967.000000</td>
      <td>950704.500000</td>
      <td>66732.000000</td>
      <td>24.000000</td>
      <td>2477.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>6176.500000</td>
      <td>5738.500000</td>
      <td>970206.500000</td>
      <td>116928.000000</td>
      <td>36.000000</td>
      <td>3934.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>6752.500000</td>
      <td>8686.000000</td>
      <td>971212.500000</td>
      <td>210654.000000</td>
      <td>48.000000</td>
      <td>5813.500000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>7308.000000</td>
      <td>11362.000000</td>
      <td>981208.000000</td>
      <td>590820.000000</td>
      <td>60.000000</td>
      <td>9910.000000</td>
    </tr>
  </tbody>
</table>
</div>


    loan_id       0
    account_id    0
    date          0
    amount        0
    duration      0
    payments      0
    status        0
    dtype: int64
    
    
    Dataframe name: order_df with number of rows:6471 and columns:6
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order_id</th>
      <th>account_id</th>
      <th>account_to</th>
      <th>amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>6471.000000</td>
      <td>6471.000000</td>
      <td>6.471000e+03</td>
      <td>6471.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>33778.197497</td>
      <td>2962.302890</td>
      <td>4.939904e+07</td>
      <td>3280.635698</td>
    </tr>
    <tr>
      <th>std</th>
      <td>3737.681949</td>
      <td>2518.503228</td>
      <td>2.888356e+07</td>
      <td>2714.475335</td>
    </tr>
    <tr>
      <th>min</th>
      <td>29401.000000</td>
      <td>1.000000</td>
      <td>3.990000e+02</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>31187.500000</td>
      <td>1223.000000</td>
      <td>2.415918e+07</td>
      <td>1241.500000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>32988.000000</td>
      <td>2433.000000</td>
      <td>4.975606e+07</td>
      <td>2596.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>34785.500000</td>
      <td>3645.500000</td>
      <td>7.400045e+07</td>
      <td>4613.500000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>46338.000000</td>
      <td>11362.000000</td>
      <td>9.999420e+07</td>
      <td>14882.000000</td>
    </tr>
  </tbody>
</table>
</div>


    order_id      0
    account_id    0
    bank_to       0
    account_to    0
    amount        0
    k_symbol      0
    dtype: int64
    
    
    Dataframe name: trans_df with number of rows:1056320 and columns:10
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>trans_id</th>
      <th>account_id</th>
      <th>date</th>
      <th>amount</th>
      <th>balance</th>
      <th>account</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1.056320e+06</td>
      <td>1.056320e+06</td>
      <td>1.056320e+06</td>
      <td>1.056320e+06</td>
      <td>1.056320e+06</td>
      <td>2.953890e+05</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1.335311e+06</td>
      <td>2.936867e+03</td>
      <td>9.656748e+05</td>
      <td>5.924146e+03</td>
      <td>3.851833e+04</td>
      <td>4.567092e+07</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.227487e+06</td>
      <td>2.477345e+03</td>
      <td>1.394535e+04</td>
      <td>9.522735e+03</td>
      <td>2.211787e+04</td>
      <td>3.066340e+07</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000e+00</td>
      <td>1.000000e+00</td>
      <td>9.301010e+05</td>
      <td>0.000000e+00</td>
      <td>-4.112570e+04</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>4.302628e+05</td>
      <td>1.204000e+03</td>
      <td>9.601160e+05</td>
      <td>1.359000e+02</td>
      <td>2.240250e+04</td>
      <td>1.782858e+07</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>8.585065e+05</td>
      <td>2.434000e+03</td>
      <td>9.704100e+05</td>
      <td>2.100000e+03</td>
      <td>3.314340e+04</td>
      <td>4.575095e+07</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2.060979e+06</td>
      <td>3.660000e+03</td>
      <td>9.802280e+05</td>
      <td>6.800000e+03</td>
      <td>4.960362e+04</td>
      <td>7.201341e+07</td>
    </tr>
    <tr>
      <th>max</th>
      <td>3.682987e+06</td>
      <td>1.138200e+04</td>
      <td>9.812310e+05</td>
      <td>8.740000e+04</td>
      <td>2.096370e+05</td>
      <td>9.999420e+07</td>
    </tr>
  </tbody>
</table>
</div>


    trans_id           0
    account_id         0
    date               0
    type               0
    operation     183114
    amount             0
    balance            0
    k_symbol      481881
    bank          782812
    account       760931
    dtype: int64
    
    
    


```python
for id, item in enumerate(files): 
    print('Dataframe name:' + str(files_name [id]))
    display(item.head (n=3))
    print('\n')
```

    Dataframe name:accounts_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>account_id</th>
      <th>district_id</th>
      <th>frequency</th>
      <th>date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>576</td>
      <td>55</td>
      <td>POPLATEK MESICNE</td>
      <td>930101</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3818</td>
      <td>74</td>
      <td>POPLATEK MESICNE</td>
      <td>930101</td>
    </tr>
    <tr>
      <th>2</th>
      <td>704</td>
      <td>55</td>
      <td>POPLATEK MESICNE</td>
      <td>930101</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    Dataframe name:cards_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>card_id</th>
      <th>disp_id</th>
      <th>type</th>
      <th>issued</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1005</td>
      <td>9285</td>
      <td>classic</td>
      <td>931107 00:00:00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>104</td>
      <td>588</td>
      <td>classic</td>
      <td>940119 00:00:00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>747</td>
      <td>4915</td>
      <td>classic</td>
      <td>940205 00:00:00</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    Dataframe name:clients_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>client_id</th>
      <th>birth_number</th>
      <th>district_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>706213</td>
      <td>18</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>450204</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>406009</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    Dataframe name:dispos_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>disp_id</th>
      <th>client_id</th>
      <th>account_id</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>OWNER</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>OWNER</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>DISPONENT</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    Dataframe name:district_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A1</th>
      <th>A2</th>
      <th>A3</th>
      <th>A4</th>
      <th>A5</th>
      <th>A6</th>
      <th>A7</th>
      <th>A8</th>
      <th>A9</th>
      <th>A10</th>
      <th>A11</th>
      <th>A12</th>
      <th>A13</th>
      <th>A14</th>
      <th>A15</th>
      <th>A16</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Hl.m. Praha</td>
      <td>Prague</td>
      <td>1204953</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>100.0</td>
      <td>12541</td>
      <td>0.29</td>
      <td>0.43</td>
      <td>167</td>
      <td>85677</td>
      <td>99107</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Benesov</td>
      <td>central Bohemia</td>
      <td>88884</td>
      <td>80</td>
      <td>26</td>
      <td>6</td>
      <td>2</td>
      <td>5</td>
      <td>46.7</td>
      <td>8507</td>
      <td>1.67</td>
      <td>1.85</td>
      <td>132</td>
      <td>2159</td>
      <td>2674</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Beroun</td>
      <td>central Bohemia</td>
      <td>75232</td>
      <td>55</td>
      <td>26</td>
      <td>4</td>
      <td>1</td>
      <td>5</td>
      <td>41.7</td>
      <td>8980</td>
      <td>1.95</td>
      <td>2.21</td>
      <td>111</td>
      <td>2824</td>
      <td>2813</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    Dataframe name:loan_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loan_id</th>
      <th>account_id</th>
      <th>date</th>
      <th>amount</th>
      <th>duration</th>
      <th>payments</th>
      <th>status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5314</td>
      <td>1787</td>
      <td>930705</td>
      <td>96396</td>
      <td>12</td>
      <td>8033.0</td>
      <td>B</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5316</td>
      <td>1801</td>
      <td>930711</td>
      <td>165960</td>
      <td>36</td>
      <td>4610.0</td>
      <td>A</td>
    </tr>
    <tr>
      <th>2</th>
      <td>6863</td>
      <td>9188</td>
      <td>930728</td>
      <td>127080</td>
      <td>60</td>
      <td>2118.0</td>
      <td>A</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    Dataframe name:order_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order_id</th>
      <th>account_id</th>
      <th>bank_to</th>
      <th>account_to</th>
      <th>amount</th>
      <th>k_symbol</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>29401</td>
      <td>1</td>
      <td>YZ</td>
      <td>87144583</td>
      <td>2452.0</td>
      <td>SIPO</td>
    </tr>
    <tr>
      <th>1</th>
      <td>29402</td>
      <td>2</td>
      <td>ST</td>
      <td>89597016</td>
      <td>3372.7</td>
      <td>UVER</td>
    </tr>
    <tr>
      <th>2</th>
      <td>29403</td>
      <td>2</td>
      <td>QR</td>
      <td>13943797</td>
      <td>7266.0</td>
      <td>SIPO</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    Dataframe name:trans_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>trans_id</th>
      <th>account_id</th>
      <th>date</th>
      <th>type</th>
      <th>operation</th>
      <th>amount</th>
      <th>balance</th>
      <th>k_symbol</th>
      <th>bank</th>
      <th>account</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>695247</td>
      <td>2378</td>
      <td>930101</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>700.0</td>
      <td>700.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>171812</td>
      <td>576</td>
      <td>930101</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>900.0</td>
      <td>900.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>207264</td>
      <td>704</td>
      <td>930101</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>1000.0</td>
      <td>1000.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    


```python
#Create a list that have a worng date column to cahnge the date dd-mm-yyyy pattern

date_cor_files = [trans_df, accounts_df, loan_df]
```


```python


def date_correction (df, col_name):
    df [col_name] = pd.to_datetime (df[col_name], format = '%y%m%d', errors = 'coerce')
    return df
```


```python
for id, item in enumerate (date_cor_files): 
    date_cor_files[id] = date_correction(item, 'date')

trans_df = date_cor_files[0]
accounts_df = date_cor_files[1]
loans_df = date_cor_files[2]
```


```python
for id, item in enumerate(files): 
    print('Dataframe name:' + str(files_name [id]))
    display(item.head (n=3))
    print('\n')
```

    Dataframe name:accounts_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>account_id</th>
      <th>district_id</th>
      <th>frequency</th>
      <th>date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>576</td>
      <td>55</td>
      <td>POPLATEK MESICNE</td>
      <td>1993-01-01</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3818</td>
      <td>74</td>
      <td>POPLATEK MESICNE</td>
      <td>1993-01-01</td>
    </tr>
    <tr>
      <th>2</th>
      <td>704</td>
      <td>55</td>
      <td>POPLATEK MESICNE</td>
      <td>1993-01-01</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    Dataframe name:cards_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>card_id</th>
      <th>disp_id</th>
      <th>type</th>
      <th>issued</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1005</td>
      <td>9285</td>
      <td>classic</td>
      <td>931107 00:00:00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>104</td>
      <td>588</td>
      <td>classic</td>
      <td>940119 00:00:00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>747</td>
      <td>4915</td>
      <td>classic</td>
      <td>940205 00:00:00</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    Dataframe name:clients_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>client_id</th>
      <th>birth_number</th>
      <th>district_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>706213</td>
      <td>18</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>450204</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>406009</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    Dataframe name:dispos_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>disp_id</th>
      <th>client_id</th>
      <th>account_id</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>OWNER</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>OWNER</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>DISPONENT</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    Dataframe name:district_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A1</th>
      <th>A2</th>
      <th>A3</th>
      <th>A4</th>
      <th>A5</th>
      <th>A6</th>
      <th>A7</th>
      <th>A8</th>
      <th>A9</th>
      <th>A10</th>
      <th>A11</th>
      <th>A12</th>
      <th>A13</th>
      <th>A14</th>
      <th>A15</th>
      <th>A16</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Hl.m. Praha</td>
      <td>Prague</td>
      <td>1204953</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>100.0</td>
      <td>12541</td>
      <td>0.29</td>
      <td>0.43</td>
      <td>167</td>
      <td>85677</td>
      <td>99107</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Benesov</td>
      <td>central Bohemia</td>
      <td>88884</td>
      <td>80</td>
      <td>26</td>
      <td>6</td>
      <td>2</td>
      <td>5</td>
      <td>46.7</td>
      <td>8507</td>
      <td>1.67</td>
      <td>1.85</td>
      <td>132</td>
      <td>2159</td>
      <td>2674</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Beroun</td>
      <td>central Bohemia</td>
      <td>75232</td>
      <td>55</td>
      <td>26</td>
      <td>4</td>
      <td>1</td>
      <td>5</td>
      <td>41.7</td>
      <td>8980</td>
      <td>1.95</td>
      <td>2.21</td>
      <td>111</td>
      <td>2824</td>
      <td>2813</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    Dataframe name:loan_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loan_id</th>
      <th>account_id</th>
      <th>date</th>
      <th>amount</th>
      <th>duration</th>
      <th>payments</th>
      <th>status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5314</td>
      <td>1787</td>
      <td>1993-07-05</td>
      <td>96396</td>
      <td>12</td>
      <td>8033.0</td>
      <td>B</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5316</td>
      <td>1801</td>
      <td>1993-07-11</td>
      <td>165960</td>
      <td>36</td>
      <td>4610.0</td>
      <td>A</td>
    </tr>
    <tr>
      <th>2</th>
      <td>6863</td>
      <td>9188</td>
      <td>1993-07-28</td>
      <td>127080</td>
      <td>60</td>
      <td>2118.0</td>
      <td>A</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    Dataframe name:order_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order_id</th>
      <th>account_id</th>
      <th>bank_to</th>
      <th>account_to</th>
      <th>amount</th>
      <th>k_symbol</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>29401</td>
      <td>1</td>
      <td>YZ</td>
      <td>87144583</td>
      <td>2452.0</td>
      <td>SIPO</td>
    </tr>
    <tr>
      <th>1</th>
      <td>29402</td>
      <td>2</td>
      <td>ST</td>
      <td>89597016</td>
      <td>3372.7</td>
      <td>UVER</td>
    </tr>
    <tr>
      <th>2</th>
      <td>29403</td>
      <td>2</td>
      <td>QR</td>
      <td>13943797</td>
      <td>7266.0</td>
      <td>SIPO</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    Dataframe name:trans_df
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>trans_id</th>
      <th>account_id</th>
      <th>date</th>
      <th>type</th>
      <th>operation</th>
      <th>amount</th>
      <th>balance</th>
      <th>k_symbol</th>
      <th>bank</th>
      <th>account</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>695247</td>
      <td>2378</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>700.0</td>
      <td>700.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>171812</td>
      <td>576</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>900.0</td>
      <td>900.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>207264</td>
      <td>704</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>1000.0</td>
      <td>1000.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>


    
    
    


```python
#change the district data column from Abrevation to required and effcient name
```


```python
district_df=district_df.rename(columns={"A1":"district_id",
                                        "A2":"District name",
                                        "A3":"Region",
                                        "A4":"No. of inhabitants",
                                        "A5":"No. of municipalities with inhabitants < 499",
                                        "A6":"No. of municipalities with inhabitants 500-1999",
                                        "A7":"No. of municipalities with inhabitants 2000-9999",
                                        "A8":"No. of municipalities with inhabitants >10000",
                                        "A9":"No. of cities",
                                        "A10":"Ratio of urban inhabitants",
                                        "A11":"Average salary",
                                        "A12":"Unemployment rate '95",
                                        "A13":"Unemployment rate '96",
                                        "A14":"No. of entrepreneurs per 1000 inhabitants",
                                        "A15":"no. of committed crimes '95",
                                        "A16":"no. of committed crimes '96"
                                    
                                       
                                       
                                       })
```


```python
district_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>district_id</th>
      <th>District name</th>
      <th>Region</th>
      <th>No. of inhabitants</th>
      <th>No. of municipalities with inhabitants &lt; 499</th>
      <th>No. of municipalities with inhabitants 500-1999</th>
      <th>No. of municipalities with inhabitants 2000-9999</th>
      <th>No. of municipalities with inhabitants &gt;10000</th>
      <th>No. of cities</th>
      <th>Ratio of urban inhabitants</th>
      <th>Average salary</th>
      <th>Unemployment rate '95</th>
      <th>Unemployment rate '96</th>
      <th>No. of entrepreneurs per 1000 inhabitants</th>
      <th>no. of committed crimes '95</th>
      <th>no. of committed crimes '96</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Hl.m. Praha</td>
      <td>Prague</td>
      <td>1204953</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>100.0</td>
      <td>12541</td>
      <td>0.29</td>
      <td>0.43</td>
      <td>167</td>
      <td>85677</td>
      <td>99107</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Benesov</td>
      <td>central Bohemia</td>
      <td>88884</td>
      <td>80</td>
      <td>26</td>
      <td>6</td>
      <td>2</td>
      <td>5</td>
      <td>46.7</td>
      <td>8507</td>
      <td>1.67</td>
      <td>1.85</td>
      <td>132</td>
      <td>2159</td>
      <td>2674</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Beroun</td>
      <td>central Bohemia</td>
      <td>75232</td>
      <td>55</td>
      <td>26</td>
      <td>4</td>
      <td>1</td>
      <td>5</td>
      <td>41.7</td>
      <td>8980</td>
      <td>1.95</td>
      <td>2.21</td>
      <td>111</td>
      <td>2824</td>
      <td>2813</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Kladno</td>
      <td>central Bohemia</td>
      <td>149893</td>
      <td>63</td>
      <td>29</td>
      <td>6</td>
      <td>2</td>
      <td>6</td>
      <td>67.4</td>
      <td>9753</td>
      <td>4.64</td>
      <td>5.05</td>
      <td>109</td>
      <td>5244</td>
      <td>5892</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Kolin</td>
      <td>central Bohemia</td>
      <td>95616</td>
      <td>65</td>
      <td>30</td>
      <td>4</td>
      <td>1</td>
      <td>6</td>
      <td>51.4</td>
      <td>9307</td>
      <td>3.85</td>
      <td>4.43</td>
      <td>118</td>
      <td>2616</td>
      <td>3040</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>72</th>
      <td>73</td>
      <td>Opava</td>
      <td>north Moravia</td>
      <td>182027</td>
      <td>17</td>
      <td>49</td>
      <td>12</td>
      <td>2</td>
      <td>7</td>
      <td>56.4</td>
      <td>8746</td>
      <td>3.33</td>
      <td>3.74</td>
      <td>90</td>
      <td>4355</td>
      <td>4433</td>
    </tr>
    <tr>
      <th>73</th>
      <td>74</td>
      <td>Ostrava - mesto</td>
      <td>north Moravia</td>
      <td>323870</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>100.0</td>
      <td>10673</td>
      <td>4.75</td>
      <td>5.44</td>
      <td>100</td>
      <td>18782</td>
      <td>18347</td>
    </tr>
    <tr>
      <th>74</th>
      <td>75</td>
      <td>Prerov</td>
      <td>north Moravia</td>
      <td>138032</td>
      <td>67</td>
      <td>30</td>
      <td>4</td>
      <td>2</td>
      <td>5</td>
      <td>64.6</td>
      <td>8819</td>
      <td>5.38</td>
      <td>5.66</td>
      <td>99</td>
      <td>4063</td>
      <td>4505</td>
    </tr>
    <tr>
      <th>75</th>
      <td>76</td>
      <td>Sumperk</td>
      <td>north Moravia</td>
      <td>127369</td>
      <td>31</td>
      <td>32</td>
      <td>13</td>
      <td>2</td>
      <td>7</td>
      <td>51.2</td>
      <td>8369</td>
      <td>4.73</td>
      <td>5.88</td>
      <td>107</td>
      <td>3736</td>
      <td>2807</td>
    </tr>
    <tr>
      <th>76</th>
      <td>77</td>
      <td>Vsetin</td>
      <td>north Moravia</td>
      <td>148545</td>
      <td>8</td>
      <td>35</td>
      <td>12</td>
      <td>3</td>
      <td>4</td>
      <td>53.5</td>
      <td>8909</td>
      <td>4.01</td>
      <td>5.56</td>
      <td>113</td>
      <td>3460</td>
      <td>3590</td>
    </tr>
  </tbody>
</table>
<p>77 rows × 16 columns</p>
</div>




```python
clients_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>client_id</th>
      <th>birth_number</th>
      <th>district_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>706213</td>
      <td>18</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>450204</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>406009</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>561201</td>
      <td>5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>605703</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python

```

# What is the demographic profile of the bank's clients and how does it vary across districts?


```python
# for that question we need to add the both data are client data and district data to check the client district profile
```


```python
#Before merge we need to change the birthnumber to birthdate and get age and gender to visualize and analyze the data
```


```python
client_data=clients_df.copy()
```


```python
client_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>client_id</th>
      <th>birth_number</th>
      <th>district_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>706213</td>
      <td>18</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>450204</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>406009</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>561201</td>
      <td>5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>605703</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
client_data = client_data.join (pd.DataFrame ( { 'birth_date': np.nan, 'gender': np.nan, 'age': np.nan}, index = clients_df.index))
```


```python
client_data['birth_date'] = client_data['birth_number']
for ids, item in enumerate (client_data['birth_number']):
    if int (str (item) [2:4]) > 50:
        client_data.loc [ids, 'gender'] = 0 #female
        client_data.loc [ids, 'birth_date'] = item - 5000 
    else: 
        client_data.loc [ids, 'gender'] = 1 
```


```python
mask = client_data["birth_date"].dt.year > 2000
client_data.loc[mask, "birth_date"] = client_data.loc[mask, "birth_date"] - pd.DateOffset(years=100)
```


```python
client_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>client_id</th>
      <th>birth_number</th>
      <th>district_id</th>
      <th>birth_date</th>
      <th>gender</th>
      <th>age</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>706213</td>
      <td>18</td>
      <td>1970-12-13</td>
      <td>0.0</td>
      <td>29</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>450204</td>
      <td>1</td>
      <td>1945-02-04</td>
      <td>1.0</td>
      <td>54</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>406009</td>
      <td>1</td>
      <td>1940-10-09</td>
      <td>0.0</td>
      <td>59</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>561201</td>
      <td>5</td>
      <td>1956-12-01</td>
      <td>1.0</td>
      <td>43</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>605703</td>
      <td>5</td>
      <td>1960-07-03</td>
      <td>0.0</td>
      <td>39</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>5364</th>
      <td>13955</td>
      <td>456030</td>
      <td>1</td>
      <td>1945-10-30</td>
      <td>0.0</td>
      <td>54</td>
    </tr>
    <tr>
      <th>5365</th>
      <td>13956</td>
      <td>430406</td>
      <td>1</td>
      <td>1943-04-06</td>
      <td>1.0</td>
      <td>56</td>
    </tr>
    <tr>
      <th>5366</th>
      <td>13968</td>
      <td>680413</td>
      <td>61</td>
      <td>1968-04-13</td>
      <td>1.0</td>
      <td>31</td>
    </tr>
    <tr>
      <th>5367</th>
      <td>13971</td>
      <td>626019</td>
      <td>67</td>
      <td>1962-10-19</td>
      <td>0.0</td>
      <td>37</td>
    </tr>
    <tr>
      <th>5368</th>
      <td>13998</td>
      <td>535812</td>
      <td>74</td>
      <td>1953-08-12</td>
      <td>0.0</td>
      <td>46</td>
    </tr>
  </tbody>
</table>
<p>5369 rows × 6 columns</p>
</div>




```python
client_data["birth_date"]=pd.to_datetime(client_data["birth_date"], format = '%y%m%d', errors = 'coerce')
```


```python
client_data["age"]=1999-client_data["birth_date"].dt.year
```


```python
district_data=district_df.copy()#Copy the data because to if we manipulate the data original data remain same 
```


```python
clients_district = pd.merge(client_data, district_data, on='district_id')
```


```python
clients_district.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>client_id</th>
      <th>birth_number</th>
      <th>district_id</th>
      <th>birth_date</th>
      <th>gender</th>
      <th>age</th>
      <th>District name</th>
      <th>Region</th>
      <th>No. of inhabitants</th>
      <th>No. of municipalities with inhabitants &lt; 499</th>
      <th>...</th>
      <th>No. of municipalities with inhabitants 2000-9999</th>
      <th>No. of municipalities with inhabitants &gt;10000</th>
      <th>No. of cities</th>
      <th>Ratio of urban inhabitants</th>
      <th>Average salary</th>
      <th>Unemployment rate '95</th>
      <th>Unemployment rate '96</th>
      <th>No. of entrepreneurs per 1000 inhabitants</th>
      <th>no. of committed crimes '95</th>
      <th>no. of committed crimes '96</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>706213</td>
      <td>18</td>
      <td>1970-12-13</td>
      <td>Female</td>
      <td>29</td>
      <td>Pisek</td>
      <td>south Bohemia</td>
      <td>70699</td>
      <td>60</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>4</td>
      <td>65.3</td>
      <td>8968</td>
      <td>2.83</td>
      <td>3.35</td>
      <td>131</td>
      <td>1740</td>
      <td>1910</td>
    </tr>
    <tr>
      <th>1</th>
      <td>420</td>
      <td>780313</td>
      <td>18</td>
      <td>1978-03-13</td>
      <td>Male</td>
      <td>21</td>
      <td>Pisek</td>
      <td>south Bohemia</td>
      <td>70699</td>
      <td>60</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>4</td>
      <td>65.3</td>
      <td>8968</td>
      <td>2.83</td>
      <td>3.35</td>
      <td>131</td>
      <td>1740</td>
      <td>1910</td>
    </tr>
    <tr>
      <th>2</th>
      <td>499</td>
      <td>355708</td>
      <td>18</td>
      <td>1935-07-08</td>
      <td>Female</td>
      <td>64</td>
      <td>Pisek</td>
      <td>south Bohemia</td>
      <td>70699</td>
      <td>60</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>4</td>
      <td>65.3</td>
      <td>8968</td>
      <td>2.83</td>
      <td>3.35</td>
      <td>131</td>
      <td>1740</td>
      <td>1910</td>
    </tr>
    <tr>
      <th>3</th>
      <td>519</td>
      <td>800413</td>
      <td>18</td>
      <td>1980-04-13</td>
      <td>Male</td>
      <td>19</td>
      <td>Pisek</td>
      <td>south Bohemia</td>
      <td>70699</td>
      <td>60</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>4</td>
      <td>65.3</td>
      <td>8968</td>
      <td>2.83</td>
      <td>3.35</td>
      <td>131</td>
      <td>1740</td>
      <td>1910</td>
    </tr>
    <tr>
      <th>4</th>
      <td>682</td>
      <td>791021</td>
      <td>18</td>
      <td>1979-10-21</td>
      <td>Male</td>
      <td>20</td>
      <td>Pisek</td>
      <td>south Bohemia</td>
      <td>70699</td>
      <td>60</td>
      <td>...</td>
      <td>2</td>
      <td>1</td>
      <td>4</td>
      <td>65.3</td>
      <td>8968</td>
      <td>2.83</td>
      <td>3.35</td>
      <td>131</td>
      <td>1740</td>
      <td>1910</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>




```python
clients_district["gender"]=clients_district["gender"].map( {0: 'Female', 1: 'Male'})
```


```python
# Count the number of clients in each district
district_client_count = clients_district['District name'].value_counts()

# Plot the distribution of clients across districts
plt.figure(figsize=(10, 6))
district_client_count.plot(kind='bar')
plt.title('Distribution of Clients Across Districts')
plt.xlabel('District')
plt.ylabel('Number of Clients')
plt.xticks(rotation=90)
plt.tight_layout()
plt.show()
```


    
![png](output_32_0.png)
    



```python
# Plot the age distribution of clients for each district
plt.figure(figsize=(10, 6))
clients_district.groupby('District name')['age'].plot(kind='hist', alpha=0.5, bins=20, legend=True)
plt.title('Age Distribution of Clients Across Districts')
plt.xlabel('Age')
plt.ylabel('Frequency')
plt.legend(title='District')
plt.tight_layout()
plt.show()
```

    C:\Users\CB SUMANTH\AppData\Local\Temp\ipykernel_13792\3839045874.py:8: UserWarning: Tight layout not applied. The bottom and top margins cannot be made large enough to accommodate all axes decorations.
      plt.tight_layout()
    


    
![png](output_33_1.png)
    



```python
#Ditrict average salary 
plt.figure(figsize=(10, 6))
clients_district.groupby('District name')['Average salary'].mean().plot(kind='bar', color='skyblue')
plt.title('Average Salary Across Districts')
plt.xlabel('District')
plt.ylabel('Average Salary')
plt.legend(title='District')
plt.xticks(rotation=90)
plt.tight_layout()
plt.show()
```


    
![png](output_34_0.png)
    



```python
# Plot the unemployment rate across districts
plt.figure(figsize=(10, 6))
clients_district.groupby('District name')['Unemployment rate \'96'].mean().plot(kind='bar', color='salmon')
plt.title('Unemployment Rate \'96 Across Districts')
plt.xlabel('District')
plt.ylabel('Unemployment Rate')
plt.legend(title='District')
plt.xticks(rotation=90)
plt.tight_layout()
plt.show()
```


    
![png](output_35_0.png)
    



```python
#Ditrict average salary 
plt.figure(figsize=(10, 6))
clients_district.groupby('Region')['Average salary'].mean().plot(kind='bar', color='skyblue')
plt.title('Average Salary Across Region')
plt.xlabel('Region')
plt.ylabel('Average Salary')
plt.legend(title='District')
plt.xticks(rotation=90)
plt.tight_layout()
plt.show()
```


    
![png](output_36_0.png)
    


#Business Question-What is the demographic profile of the bank's clients and how does it vary across districts?

We extract the date,age and gender through client data.To view the required insight to analyze the data.
To perform a bank client and district data we need to merge the data through district id and get the personalyzed data.

Through Data:
    We check the 1)Distribution of Clients Across Districts
                 2)Age Distribution of Clients Across Districts
                 3)Average Salary Across Districts
                 4)Unemployment Rate \96 Across Districts
                 5)Average Salary Across Region


```python

```

# How the banks have performed over the years. Give their detailed analysis year & month-wise.


```python

```


```python
trans_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>trans_id</th>
      <th>account_id</th>
      <th>date</th>
      <th>type</th>
      <th>operation</th>
      <th>amount</th>
      <th>balance</th>
      <th>k_symbol</th>
      <th>bank</th>
      <th>account</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>695247</td>
      <td>2378</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>700.0</td>
      <td>700.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>171812</td>
      <td>576</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>900.0</td>
      <td>900.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>207264</td>
      <td>704</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>1000.0</td>
      <td>1000.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1117247</td>
      <td>3818</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>600.0</td>
      <td>600.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>579373</td>
      <td>1972</td>
      <td>1993-01-02</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>400.0</td>
      <td>400.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
trans_data=trans_df.copy()
```


```python

```


```python
# Convert 'date' column to datetime format
trans_data['date'] = pd.to_datetime(trans_data['date'])

# Extract year and month from the date column
trans_data['year'] = trans_data['date'].dt.year
trans_data['month'] = trans_data['date'].dt.month

# Group by year and month and calculate financial metrics
bank_performance = trans_data.groupby(['year', 'month']).agg({
    'amount': 'sum',        # Total amount transacted
    'balance': 'mean',      # Average account balance
    'trans_id': 'count'     # Number of transactions
}).reset_index()


```


```python
# Plotting the bank performance metrics
plt.figure(figsize=(12, 8))


plt.plot(bank_performance['amount'], marker='o', color='blue')
plt.title('Total Amount Transacted Over Time')
plt.xlabel('Time')
plt.ylabel('Total Amount')
plt.tight_layout()
plt.show()
```


    
![png](output_45_0.png)
    



```python
plt.figure(figsize=(12, 8))
plt.plot(bank_performance['balance'], marker='o', color='green')
plt.title('Average Account Balance Over Time')
plt.xlabel('Time')
plt.ylabel('Average Balance')
plt.tight_layout()
plt.show()
```


    
![png](output_46_0.png)
    



```python
plt.figure(figsize=(12, 8))
plt.plot(bank_performance['trans_id'], marker='o', color='orange')
plt.title('Number of Transactions Over Time')
plt.xlabel('Time')
plt.ylabel('Number of Transactions')

plt.tight_layout()
plt.show()
```


    
![png](output_47_0.png)
    



```python
#Bank Transaction happend in every Year
x=trans_data["year"]
y=trans_data["year"].value_counts()
```


```python
#yearly plot

plt.plot(y)
plt.xlabel("Years")
plt.ylabel("Values")
plt.title("No of transaction happend in the every year")
plt.show()
```


    
![png](output_49_0.png)
    



```python
month_codes = {
        1: 'Jan',
        2: 'Feb',
        3: 'Mar',
        4: 'Apr',
        5: 'May',
        6: 'Jun',
        7: 'Jul',
        8: 'Aug',
        9: 'Sep',
        10: 'Oct',
        11: 'Nov',
        12: 'Dec'
    }
```


```python
trans_data["month"] = trans_data["month"].map(month_codes)
```


```python
#Bank Transaction happend in every month
x=trans_data["month"]
y=trans_data["month"].value_counts()
```


```python
#monthly plot
trans_data["month"].value_counts().plot(kind="bar")
plt.xlabel("month")
plt.ylabel("Values")
plt.title("No of transaction happend in the every month")
plt.show()
```


    
![png](output_53_0.png)
    



```python
#Monthly plot transction shown in number
plt.plot(y)
plt.xlabel("month")
plt.ylabel("Values")
for i, v in enumerate(y):
    plt.text(i, v + 0.5, str(v), ha='center')
plt.title("No of transaction happend in the every month")
plt.show()
```


    
![png](output_54_0.png)
    



```python
#yearly amount 
x=trans_data["year"]
y=trans_data["amount"].sum()
```


```python
data={"year":x,"Amount sum":y}
```


```python
df = pd.DataFrame(data)

# Aggregate the data by year and sum the amounts
df_agg = df.groupby('year')['Amount sum'].sum().reset_index()

# Plot the aggregated data
sns.barplot(x='year', y='Amount sum', data=df_agg)
plt.xlabel("Year")
plt.ylabel("Total Amount")
plt.title("Total Amount per Year")
plt.show()
```


    
![png](output_57_0.png)
    



```python
# Plot the aggregated data
sns.lineplot(x='year', y='Amount sum', data=df_agg)
plt.xlabel("Year")
plt.ylabel("Total Amount")
plt.title("Total Amount per Year")
plt.show()
```


    
![png](output_58_0.png)
    



```python
#total amount sum in every month
x=trans_data["month"]
y=trans_data["amount"].sum()
```


```python
data={"month":x,"Amount sum":y}
```


```python
df = pd.DataFrame(data)

# Aggregate the data by year and sum the amounts
df_agg = df.groupby('month')['Amount sum'].sum().reset_index()

# Plot the aggregated data
sns.barplot(x='month', y='Amount sum', data=df_agg)
plt.xlabel("month")
plt.ylabel("Total Amount")
plt.title("Total Amount per month")
plt.show()
```


    
![png](output_61_0.png)
    



```python
sns.lineplot(x='month', y='Amount sum', data=df_agg)
plt.xlabel("month")
plt.ylabel("Total Amount")
plt.title("Total Amount per month")
plt.show()
```


    
![png](output_62_0.png)
    



```python
#Check the balance on every year

x=trans_data["year"]
y=trans_data["balance"].sum()
```


```python
data={"year":x,"Balance sum":y}
```


```python
df = pd.DataFrame(data)

# Aggregate the data by year and sum the amounts
df_agg = df.groupby('year')['Balance sum'].sum().reset_index()

# Plot the aggregated data
sns.barplot(x='year', y='Balance sum', data=df_agg)
plt.xlabel("Year")
plt.ylabel("Total Balance")
plt.title("Total Balance per month")
plt.show()
```


    
![png](output_65_0.png)
    



```python
#month amount

x=trans_data["month"]
y=trans_data["balance"].sum()
```


```python
data={"month":x,"Balance sum":y}
```


```python
df = pd.DataFrame(data)

# Aggregate the data by year and sum the amounts
df_agg = df.groupby('month')['Balance sum'].sum().reset_index()

# Plot the aggregated data
sns.barplot(x='month', y='Balance sum', data=df_agg)
plt.xlabel("month")
plt.ylabel("Total Balance")
plt.title("Total Balance per month")
plt.show()
```


    
![png](output_68_0.png)
    



```python
trans_data["date"].min()
```




    Timestamp('1993-01-01 00:00:00')




```python
trans_data["date"].max()
```




    Timestamp('1998-12-31 00:00:00')




```python
trans_data["amount"].sum()
```




    6257793560.300002




```python
trans_data["amount"].mean()
```




    5924.1456758368695




```python
trans_data["balance"].sum()
```




    40687683193.99999




```python
trans_data["balance"].mean()
```




    38518.3308031657



#Business Question-How the banks have performed over the years. Give their detailed analysis year & month-wise?

We did the sum,mean of every month,every year of amount and balance in the data.

Through Data:
    We check the 1)Month-amount and Year-mean plot to chect the min and max values data month and year through data plot.
                 2)Month-balance and Year-balance plot to chect the min and max values data month and year through data plot.
                 3)We generate a timestrap plot to check the performance of detailed analysis of year and month.
                 4)We get the mean amount result 5924.145 and sum is 6257793560.300002.
                 5)We get the mean balance result 38518.33 and sum is 40687683193.99999.


```python

```

# What are the most common types of accounts and how do they differ in terms of usage and profitability?


```python
account_data=accounts_df.copy()
```


```python
trans_dataa=trans_df.copy()
```


```python
account_trans = pd.merge(account_data, trans_dataa, on='account_id')
```


```python
account_trans.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>account_id</th>
      <th>district_id</th>
      <th>frequency</th>
      <th>date_x</th>
      <th>trans_id</th>
      <th>date_y</th>
      <th>type</th>
      <th>operation</th>
      <th>amount</th>
      <th>balance</th>
      <th>k_symbol</th>
      <th>bank</th>
      <th>account</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>576</td>
      <td>55</td>
      <td>POPLATEK MESICNE</td>
      <td>1993-01-01</td>
      <td>171812</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>900.0</td>
      <td>900.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>576</td>
      <td>55</td>
      <td>POPLATEK MESICNE</td>
      <td>1993-01-01</td>
      <td>171813</td>
      <td>1993-01-11</td>
      <td>PRIJEM</td>
      <td>PREVOD Z UCTU</td>
      <td>6207.0</td>
      <td>7107.0</td>
      <td>DUCHOD</td>
      <td>YZ</td>
      <td>30300313.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>576</td>
      <td>55</td>
      <td>POPLATEK MESICNE</td>
      <td>1993-01-01</td>
      <td>3549613</td>
      <td>1993-01-31</td>
      <td>PRIJEM</td>
      <td>NaN</td>
      <td>20.1</td>
      <td>7127.1</td>
      <td>UROK</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>576</td>
      <td>55</td>
      <td>POPLATEK MESICNE</td>
      <td>1993-01-01</td>
      <td>171814</td>
      <td>1993-02-11</td>
      <td>PRIJEM</td>
      <td>PREVOD Z UCTU</td>
      <td>6207.0</td>
      <td>13334.1</td>
      <td>DUCHOD</td>
      <td>YZ</td>
      <td>30300313.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>576</td>
      <td>55</td>
      <td>POPLATEK MESICNE</td>
      <td>1993-01-01</td>
      <td>3549614</td>
      <td>1993-02-28</td>
      <td>PRIJEM</td>
      <td>NaN</td>
      <td>29.6</td>
      <td>13363.7</td>
      <td>UROK</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
account_profitability = account_trans.groupby('frequency').agg({
    'amount': 'sum',        # Total transaction amount
    'balance': 'mean'      # Average account balance
})

# Plotting profitability metrics
plt.figure(figsize=(10, 6))
account_profitability.plot(kind='bar', rot=0)
plt.title('Profitability by Account Type')
plt.xlabel('Account Type')
plt.ylabel('Value')
plt.legend(['Total Transaction Amount', 'Average Balance'])
plt.tight_layout()
plt.show()
```


    <Figure size 1000x600 with 0 Axes>



    
![png](output_82_1.png)
    



```python
a=account_trans["frequency"].value_counts()
b=account_trans["type"].value_counts()
c=account_trans["operation"].value_counts()
```


```python
a,b,c
```




    (frequency
     POPLATEK MESICNE      969253
     POPLATEK TYDNE         62567
     POPLATEK PO OBRATU     24500
     Name: count, dtype: int64,
     type
     VYDAJ     634571
     PRIJEM    405083
     VYBER      16666
     Name: count, dtype: int64,
     operation
     VYBER             434918
     PREVOD NA UCET    208283
     VKLAD             156743
     PREVOD Z UCTU      65226
     VYBER KARTOU        8036
     Name: count, dtype: int64)




```python
# Plot pie charts for each dataset
plt.figure(figsize=(15, 5))
plt.pie(a, labels=a.index, autopct='%1.1f%%')
plt.title('Account Trans frequency Percentage')
plt.tight_layout()
plt.show()
```


    
![png](output_85_0.png)
    



```python
plt.pie(b, labels=b.index, autopct='%1.1f%%')
plt.title('Account Trans Type Percentage')
```




    Text(0.5, 1.0, 'Account Trans Type Percentage')




    
![png](output_86_1.png)
    



```python
plt.pie(c, labels=c.index, autopct='%1.1f%%')
plt.title('Account Trans operation Percentage')
```




    Text(0.5, 1.0, 'Account Trans operation Percentage')




    
![png](output_87_1.png)
    


#Bussiness Question-What are the most common types of accounts and how do they differ in terms of usage and profitability?

We check the transaction of frequency percentage,Type,operation percentage to check their performance impact on profitability

From data we have :
          A)"Account Trans frequency Percentage" of frequency of issuance of statements: "POPLATEK MESICNE" stands for monthly               issuance is 91.8%."POPLATEK TYDNE" stands for weekly issuance is 5.9%. "POPLATEK PO OBRATU" stands for issuance                 after transaction is 2.3%
          B)"Account Trans Type Percentage" VYDAJ is 60.1% Withdrawl and Prijem is 38.3% and VYBER 1.6% withdrawl in cash.
          C)"Account Trans operation Percentage" of mode of transaction: "VYBER KARTOU" credit card withdrawal is 0.9%, "VKLAD"             credit in cash is 18% ,"PREVOD Z UCTU" collection from another bank  is 7.5%,"VYBER" withdrawal in cash is 49.8%,                "PREVOD NA UCET" remittance to another bank is 23.9%.


```python

```


```python
#Which types of cards are most frequently used by the bank's clients and what is the overall profitability of the credit card business?
```


```python
cards_data=cards_df.copy()
```


```python
dispos_data=dispos_df.copy()
```


```python
card_clients = pd.merge(cards_data, dispos_data, on='disp_id')
```


```python
card_clients.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>card_id</th>
      <th>disp_id</th>
      <th>type_x</th>
      <th>issued</th>
      <th>client_id</th>
      <th>account_id</th>
      <th>type_y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1005</td>
      <td>9285</td>
      <td>classic</td>
      <td>931107 00:00:00</td>
      <td>9593</td>
      <td>7753</td>
      <td>OWNER</td>
    </tr>
    <tr>
      <th>1</th>
      <td>104</td>
      <td>588</td>
      <td>classic</td>
      <td>940119 00:00:00</td>
      <td>588</td>
      <td>489</td>
      <td>OWNER</td>
    </tr>
    <tr>
      <th>2</th>
      <td>747</td>
      <td>4915</td>
      <td>classic</td>
      <td>940205 00:00:00</td>
      <td>4915</td>
      <td>4078</td>
      <td>OWNER</td>
    </tr>
    <tr>
      <th>3</th>
      <td>70</td>
      <td>439</td>
      <td>classic</td>
      <td>940208 00:00:00</td>
      <td>439</td>
      <td>361</td>
      <td>OWNER</td>
    </tr>
    <tr>
      <th>4</th>
      <td>577</td>
      <td>3687</td>
      <td>classic</td>
      <td>940215 00:00:00</td>
      <td>3687</td>
      <td>3050</td>
      <td>OWNER</td>
    </tr>
  </tbody>
</table>
</div>




```python
a=card_clients["type_x"].value_counts()
```


```python
a.plot(kind='bar', subplots=True)
plt.title('Credit Card Analysis')
plt.xlabel('Card Type')
plt.ylabel('Credit Card Count')
plt.show()
```


    
![png](output_96_0.png)
    



```python
card_combine_data=pd.merge(card_clients,trans_data[["account_id","trans_id","amount","balance"]] ,on='account_id', how='left')
```


```python
card_combine_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>card_id</th>
      <th>disp_id</th>
      <th>type_x</th>
      <th>issued</th>
      <th>client_id</th>
      <th>account_id</th>
      <th>type_y</th>
      <th>trans_id</th>
      <th>amount</th>
      <th>balance</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1005</td>
      <td>9285</td>
      <td>classic</td>
      <td>931107 00:00:00</td>
      <td>9593</td>
      <td>7753</td>
      <td>OWNER</td>
      <td>2349697</td>
      <td>600.0</td>
      <td>600.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1005</td>
      <td>9285</td>
      <td>classic</td>
      <td>931107 00:00:00</td>
      <td>9593</td>
      <td>7753</td>
      <td>OWNER</td>
      <td>2349709</td>
      <td>19588.0</td>
      <td>20188.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1005</td>
      <td>9285</td>
      <td>classic</td>
      <td>931107 00:00:00</td>
      <td>9593</td>
      <td>7753</td>
      <td>OWNER</td>
      <td>2349705</td>
      <td>27078.0</td>
      <td>47266.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1005</td>
      <td>9285</td>
      <td>classic</td>
      <td>931107 00:00:00</td>
      <td>9593</td>
      <td>7753</td>
      <td>OWNER</td>
      <td>3492040</td>
      <td>119.6</td>
      <td>47385.6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1005</td>
      <td>9285</td>
      <td>classic</td>
      <td>931107 00:00:00</td>
      <td>9593</td>
      <td>7753</td>
      <td>OWNER</td>
      <td>2350078</td>
      <td>12000.0</td>
      <td>35385.6</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Calculate sum and mean of amounts for each card type
classic_sum = card_combine_data[card_combine_data['type_x'] == 'classic']['amount'].sum()
classic_mean = card_combine_data[card_combine_data['type_x'] == 'classic']['amount'].mean()

# Print results for classic card type
print("Classic Card Type:")
print("Sum of Amounts:", classic_sum)
print("Mean of Amounts:", classic_mean)
```

    Classic Card Type:
    Sum of Amounts: 1379598191.9
    Mean of Amounts: 8630.093969685786
    


```python
# Calculate sum and mean of amounts for each card type
junior_sum = card_combine_data[card_combine_data['type_x'] == 'junior']['amount'].sum()
junior_mean = card_combine_data[card_combine_data['type_x'] == 'junior']['amount'].mean()

# Print results for classic card type
print("Junior Card Type:")
print("Sum of Amounts:", junior_sum)
print("Mean of Amounts:", junior_mean)
```

    Junior Card Type:
    Sum of Amounts: 277503022.7
    Mean of Amounts: 7636.506857646055
    


```python
# Calculate sum and mean of amounts for each card type
gold_sum = card_combine_data[card_combine_data['type_x'] == 'gold']['amount'].sum()
gold_mean = card_combine_data[card_combine_data['type_x'] == 'gold']['amount'].mean()

# Print results for classic card type
print("Gold Card Type:")
print("Sum of Amounts:", gold_sum)
print("Mean of Amounts:", gold_mean)
```

    Gold Card Type:
    Sum of Amounts: 234447867.50000003
    Mean of Amounts: 9108.308760683762
    


```python
sum_of_data=[classic_sum,junior_sum,gold_sum]

mean_of_data=[classic_mean,junior_mean,gold_mean]
```


```python
card_types = ['Classic', 'Junior', 'Gold']

# Plot
fig, ax = plt.subplots(1, 2, figsize=(12, 6))

# Plot for sum
ax[0].bar(card_types, sum_of_data, color='skyblue')
ax[0].set_title('Sum of Amount by Card Type')
ax[0].set_xlabel('Card Type')
ax[0].set_ylabel('Sum of Amount')

# Plot for mean
ax[1].bar(card_types, mean_of_data, color='lightgreen')
ax[1].set_title('Mean of Amount by Card Type')
ax[1].set_xlabel('Card Type')
ax[1].set_ylabel('Mean of Amount')

plt.tight_layout()
plt.show()
```


    
![png](output_103_0.png)
    



```python
card_type_profitability = card_combine_data.groupby('type_x')['amount'].sum()
```


```python
overall_profitability = card_type_profitability.sum()
```


```python
overall_profitability
```




    1891549082.1000001



#Which types of cards are most frequently used by the bank's clients and what is the overall profitability of the credit card business?

In this data question to show the distribution of cards types percentage,sum and mean of all credit cards types.
We got the overall_profitability sum of all credit card total amount.


```python

```

# What are the major expenses of the bank and how can they be reduced to improve profitability?


```python

```


```python
trans_data=trans_df.copy()
```


```python
trans_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>trans_id</th>
      <th>account_id</th>
      <th>date</th>
      <th>type</th>
      <th>operation</th>
      <th>amount</th>
      <th>balance</th>
      <th>k_symbol</th>
      <th>bank</th>
      <th>account</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>695247</td>
      <td>2378</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>700.0</td>
      <td>700.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>171812</td>
      <td>576</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>900.0</td>
      <td>900.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>207264</td>
      <td>704</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>1000.0</td>
      <td>1000.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1117247</td>
      <td>3818</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>600.0</td>
      <td>600.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>579373</td>
      <td>1972</td>
      <td>1993-01-02</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>400.0</td>
      <td>400.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
trans_data["k_symbol"].value_counts()
```




    k_symbol
    UROK           183114
    SLUZBY         155832
    SIPO           118065
                    53433
    DUCHOD          30338
    POJISTNE        18500
    UVER            13580
    SANKC. UROK      1577
    Name: count, dtype: int64




```python
trans_data['k_symbol'].replace({" ": "Null"}, inplace=True)
```


```python
trans_data["k_symbol"].value_counts()
```




    k_symbol
    UROK           183114
    SLUZBY         155832
    SIPO           118065
    Null            53433
    DUCHOD          30338
    POJISTNE        18500
    UVER            13580
    SANKC. UROK      1577
    Name: count, dtype: int64




```python
#Trans Exp bank in each year
trans_data['year'] = pd.to_datetime(trans_data['date']).dt.year
```


```python
# Group the DataFrame by year and transaction type, and calculate total amount for each type in each year
exp_summ_data_year=trans_data.groupby(['year', 'type'])['amount'].sum().unstack()
# Calculate the percentage of each transaction type for each year
expense_summary_percentage = exp_summ_data_year.div(exp_summ_data_year.sum(axis=1), axis=0) * 100
```


```python
# Plotting the percentage plot
plt.figure(figsize=(10, 6))
expense_summary_percentage.plot(kind='bar', stacked=True)
plt.title('Percentage of Credit and Withdrawal Amounts by Year')
plt.xlabel('Year')
plt.ylabel('Percentage')
plt.xticks(rotation=45)
plt.legend(title='Transaction Type')
plt.tight_layout()
plt.show()
```


    <Figure size 1000x600 with 0 Axes>



    
![png](output_118_1.png)
    



```python
#Trans Exp bank in each operation
expense_trans_oper = trans_data[trans_data['operation'].notnull()]

# Group expense transactions by operation and calculate total expenses for each operation
operation_expenses = expense_trans_oper.groupby('operation')['amount'].sum().sort_values(ascending=False)

# Display operation expenses data
print(operation_expenses)
```

    operation
    VKLAD             2.418522e+09
    VYBER             2.339513e+09
    PREVOD Z UCTU     7.814800e+08
    PREVOD NA UCET    6.726378e+08
    VYBER KARTOU      1.817040e+07
    Name: amount, dtype: float64
    


```python
# Calculate the total expenses for all operations
total_expenses = operation_expenses.sum()

# Calculate the percentage of each operation
operation_percentages = (operation_expenses / total_expenses) * 100

# Plot the pie chart
plt.figure(figsize=(8, 8))
plt.pie(operation_expenses, labels=operation_expenses.index, autopct='%1.1f%%', startangle=140)
plt.title('Operation Expenses Distribution')
plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
plt.show()
```


    
![png](output_120_0.png)
    



```python
#Trans Exp bank in each k_symbol amount percentage 
# Assuming 'trans_data' is your transaction DataFrame

# Filter transaction data to include only expense transactions
expense_transactions = trans_data[trans_data['operation'].notnull()]

# Group expense transactions by 'k_symbol' and calculate count and sum
k_symbol_expenses = expense_transactions.groupby('k_symbol')['amount'].agg(['count', 'sum'])

# Calculate total expenses
total_expenses = k_symbol_expenses['sum'].sum()

# Calculate percentage of expenses for each k_symbol
k_symbol_expenses['percentage'] = (k_symbol_expenses['sum'] / total_expenses) * 100
```


```python
# Plot the bar graph
plt.figure(figsize=(12, 6))
plt.bar(k_symbol_expenses.index, k_symbol_expenses['sum'], color='orange', alpha=0.7, label='Sum')
plt.ylabel('Count / Sum')
plt.xlabel('k_symbol')
plt.title('Expenses by k_symbol')
plt.legend()
# Add percentage labels on the bars
for i, perc in enumerate(k_symbol_expenses['percentage']):
    plt.text(i, k_symbol_expenses.iloc[i]['sum'] + 100, f'{perc:.2f}%', ha='center')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
```


    
![png](output_122_0.png)
    


In above generated code i show the the bank expenses happen through operation,trans,k_symbol:
    A)Percentage of Credit and Withdrawal Amounts by Year
    B)Operation Expenses Distribution
    C)Expenses by k_symbol


```python

```

# What is the bank’s loan portfolio and how does it vary across different purposes and client segments?


```python
loan_data=loan_df.copy()
```


```python
dispos_data=dispos_df.copy()
```


```python
loan_info = pd.merge(loan_data, dispos_data, on='account_id')
```


```python
clients_data=clients_df.copy()
```


```python
loan_info = pd.merge(loan_info, clients_data, on='client_id')
```


```python
loan_info.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loan_id</th>
      <th>account_id</th>
      <th>date</th>
      <th>amount</th>
      <th>duration</th>
      <th>payments</th>
      <th>status</th>
      <th>disp_id</th>
      <th>client_id</th>
      <th>type</th>
      <th>birth_number</th>
      <th>district_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5314</td>
      <td>1787</td>
      <td>1993-07-05</td>
      <td>96396</td>
      <td>12</td>
      <td>8033.0</td>
      <td>B</td>
      <td>2166</td>
      <td>2166</td>
      <td>OWNER</td>
      <td>475722</td>
      <td>30</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5316</td>
      <td>1801</td>
      <td>1993-07-11</td>
      <td>165960</td>
      <td>36</td>
      <td>4610.0</td>
      <td>A</td>
      <td>2181</td>
      <td>2181</td>
      <td>OWNER</td>
      <td>680722</td>
      <td>46</td>
    </tr>
    <tr>
      <th>2</th>
      <td>6863</td>
      <td>9188</td>
      <td>1993-07-28</td>
      <td>127080</td>
      <td>60</td>
      <td>2118.0</td>
      <td>A</td>
      <td>11006</td>
      <td>11314</td>
      <td>OWNER</td>
      <td>360602</td>
      <td>45</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5325</td>
      <td>1843</td>
      <td>1993-08-03</td>
      <td>105804</td>
      <td>36</td>
      <td>2939.0</td>
      <td>A</td>
      <td>2235</td>
      <td>2235</td>
      <td>OWNER</td>
      <td>405420</td>
      <td>14</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7240</td>
      <td>11013</td>
      <td>1993-09-06</td>
      <td>274740</td>
      <td>60</td>
      <td>4579.0</td>
      <td>A</td>
      <td>13231</td>
      <td>13539</td>
      <td>OWNER</td>
      <td>780907</td>
      <td>63</td>
    </tr>
  </tbody>
</table>
</div>




```python
loan_info['status_desc'] = loan_info['status']

dict1 =  {'A':'Contract finished, no problem', 
      'B':'Contract finised, loan was not paid',
      'C':'Runing contract, OK so far',
      'D':'Runing contract, client in debt'
     }
loan_info.status_desc = loan_info.status_desc.replace(dict1)

loan_info['status_numeric'] = loan_info['status']

#encoding bad loans as 1 and good ones as -1 
dict2 =  {'A':1, 
      'B':-1,
      'C':1,
      'D':-1
     }

```


```python
loan_info.status_numeric = loan_info.status_numeric.replace (dict2)
display(loan_info.head (n=3))
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loan_id</th>
      <th>account_id</th>
      <th>date</th>
      <th>amount</th>
      <th>duration</th>
      <th>payments</th>
      <th>status</th>
      <th>disp_id</th>
      <th>client_id</th>
      <th>type</th>
      <th>birth_number</th>
      <th>district_id</th>
      <th>status_desc</th>
      <th>status_numeric</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5314</td>
      <td>1787</td>
      <td>1993-07-05</td>
      <td>96396</td>
      <td>12</td>
      <td>8033.0</td>
      <td>B</td>
      <td>2166</td>
      <td>2166</td>
      <td>OWNER</td>
      <td>475722</td>
      <td>30</td>
      <td>Contract finised, loan was not paid</td>
      <td>-1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5316</td>
      <td>1801</td>
      <td>1993-07-11</td>
      <td>165960</td>
      <td>36</td>
      <td>4610.0</td>
      <td>A</td>
      <td>2181</td>
      <td>2181</td>
      <td>OWNER</td>
      <td>680722</td>
      <td>46</td>
      <td>Contract finished, no problem</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>6863</td>
      <td>9188</td>
      <td>1993-07-28</td>
      <td>127080</td>
      <td>60</td>
      <td>2118.0</td>
      <td>A</td>
      <td>11006</td>
      <td>11314</td>
      <td>OWNER</td>
      <td>360602</td>
      <td>45</td>
      <td>Contract finished, no problem</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



```python
a=loan_info["type"].value_counts()
```


```python
a.plot(kind='bar', subplots=True)
plt.title('Loan Type Analysis')
plt.xlabel('Loan Type')
plt.ylabel('Loan Type Count')
plt.show()
```


    
![png](output_135_0.png)
    



```python
total=loan_info["amount"].sum()
a=loan_info[loan_info["type"] == "OWNER"]["amount"].sum()
b=loan_info[loan_info["type"] == "DISPONENT"]["amount"].sum()
```


```python
labels = ["OWNER", 'DISPONENT']
sizes = [a, b]

plt.figure(figsize=(8, 8))
plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140)
plt.title('Loan Distribution by Category')
plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
plt.show()
```


    
![png](output_137_0.png)
    



```python
status_counts = loan_info["status_numeric"].value_counts()

# Plotting the bar graph
plt.figure(figsize=(8, 6))
status_counts.plot(kind='bar', color='skyblue')
plt.title('Loan Status Distribution')
plt.xlabel('Status Numeric')
plt.ylabel('Count')
plt.xticks(rotation=0)  # Rotate x-axis labels if needed
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.show()
```


    
![png](output_138_0.png)
    



```python
# Count the occurrences of each unique value in 'status_numeric' column
status_counts = loan_info["status_numeric"].value_counts()

# Plotting the pie chart
plt.figure(figsize=(8, 8))
plt.pie(status_counts, labels=status_counts.index, autopct='%1.1f%%', startangle=140)
plt.title('Loan Status info')
plt.legend(["On Time", "Delayed Time"], title="Loan Status")
plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
plt.show()
```


    
![png](output_139_0.png)
    



```python
status_counts = loan_info["status_desc"].value_counts()

# Plotting the bar graph
plt.figure(figsize=(8, 6))
status_counts.plot(kind='bar', color='skyblue')
plt.title('Loan Status Distribution')
plt.xlabel('Status Numeric')
plt.ylabel('Count')
plt.xticks(rotation=90)  # Rotate x-axis labels if needed
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.show()
```


    
![png](output_140_0.png)
    



```python
# Count the occurrences of each unique value in 'status_numeric' column
status_counts = loan_info["status_desc"].value_counts()

# Plotting the pie chart
plt.figure(figsize=(8, 8))
plt.pie(status_counts, labels=status_counts.index, autopct='%1.1f%%', startangle=140)
plt.title('Loan Status info')
plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
plt.show()
```


    
![png](output_141_0.png)
    



```python
numerical_columns = ['amount', 'duration', 'payments']
```


```python
loan_info['status_numeric'] = pd.to_numeric(loan_info['status_numeric'], errors='coerce')

# Adding 'status_numeric' column to the list of numerical columns
numerical_columns.append('status_numeric')

# Calculate correlation matrix
correlation_matrix = loan_info[numerical_columns].corr()

# Print correlation matrix
print("Correlation Matrix:")
print(correlation_matrix)
```

    Correlation Matrix:
                      amount  duration  payments  status_numeric
    amount          1.000000  0.615840  0.683020       -0.147798
    duration        0.615840  1.000000 -0.042414       -0.027352
    payments        0.683020 -0.042414  1.000000       -0.156414
    status_numeric -0.147798 -0.027352 -0.156414        1.000000
    


```python
sns.heatmap(correlation_matrix, annot = True, fmt=".2f");
```


    
![png](output_144_0.png)
    



```python
district_names=[]

for i in range(len(loan_info)):
    district_id = loan_info.loc[i, "district_id"]
    district_name = district_df[district_df["district_id"] == district_id]["District name"].values
    if len(district_name) > 0:
        district_names.append(district_name[0])
    else:
        # If no corresponding district name is found, append "Nan"
        district_names.append("Nan")
```


```python
loan_info["district_name"]=district_names
```


```python
loan_info["district_name"].value_counts()
```




    district_name
    Hl.m. Praha          98
    Karvina              28
    Brno - mesto         28
    Ostrava - mesto      25
    Zlin                 20
                         ..
    Usti nad Labem        3
    Pisek                 3
    Jablonec n. Nisou     2
    Domazlice             2
    Sokolov               1
    Name: count, Length: 77, dtype: int64




```python
# Group loans by district and calculate the number of loans for each district
district_loan_counts = loan_info['district_name'].value_counts()

# Calculate the percentage of loans for each district
total_loans = district_loan_counts.sum()
district_loan_percentages = (district_loan_counts / total_loans) * 100

# Plotting percentage view of loan portfolio by district
plt.figure(figsize=(12, 8))
district_loan_percentages.plot(kind='bar', color='skyblue')
plt.title('Percentage View of Loan Portfolio by District')
plt.xlabel('District ID')
plt.ylabel('Percentage of Loans')
plt.xticks(rotation=90)
plt.tight_layout()
plt.show()
```


    
![png](output_148_0.png)
    



```python
district_loan_percentages.max()
```




    11.85006045949214




```python
district_loan_percentages.min()
```




    0.12091898428053204




```python

```


```python
Bussiness Question of Loan Data info we merge the data loan,disp,client data for better understanding.

We check and visualize the data through differnt parameters like:
    A)Loan Type Analysis
    B)Loan Distribution by Category
    C)Loan Status Distribution
    D)To check the time status of Loan Status.
    E)Loan Status Distribution on different category.

Above visualization provide the better view insight to analyze the data.
```


```python

```

# How can the bank improve its customer service and satisfaction levels?

Improving customer service and satisfaction levels can be achieved through various strategies based on the insights derived from the data. Here's how you can approach it.


```python
Transaction Analysis:
```

Through Transaction data to find the trends based on year,month on amount and balance the result shows that every year the transaction increase year by year.
Providing the better connectivity and knowledge on saving can cost the better transaction result.


```python
Analyze Customer Feedback:
```
If available,analyze any customer feedback or complaints data to identify common issues and pain points.This could include complaints related to account management, transaction processing, or customer support.
Improving Communication Channels:

Evaluate the effectiveness of existing communication channels for example phone support, email, chat. Consider implementing new channels or improving existing ones to provide faster and more efficient customer support.


```python
Personalized Recommendations:
```

Utilize transaction history to offer personalized recommendations to customers. This could include suggesting relevant banking products or services based on their transaction patterns and financial needs.


```python
Community Engagement:
```

Engage with the community through events, workshops, or social media to build trust and strengthen relationships with customers. This could include financial literacy workshops or community outreach programs.


```python

```

# Can the bank introduce new financial products or services to attract more customers and increase profitability?

Here are my top picks for bank can introduce new financial products or services to attract more customers:

Yes,Bank can introduce new financial products or services:
    A)House Loan for compounding interest.
    B)Providing Platinum credit card for high budget payment.
    C)Business and Entrepeneur Bond for equity percent share.
    D)Gold Loan for simple interest.
    E)Health Beneficiary insurance and loan.


```python

```


```python
Here how bank can increase profitability on financial products or services.
A)Due interest on loan amount
B)More than 50 transaction on every month can charge 2% in total sum of amount transferd.
C)Minimun Balance Account
D)Credit Card Charges
```


```python
loan_data=loan_df.copy()
```


```python
loan_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loan_id</th>
      <th>account_id</th>
      <th>date</th>
      <th>amount</th>
      <th>duration</th>
      <th>payments</th>
      <th>status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5314</td>
      <td>1787</td>
      <td>1993-07-05</td>
      <td>96396</td>
      <td>12</td>
      <td>8033.0</td>
      <td>B</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5316</td>
      <td>1801</td>
      <td>1993-07-11</td>
      <td>165960</td>
      <td>36</td>
      <td>4610.0</td>
      <td>A</td>
    </tr>
    <tr>
      <th>2</th>
      <td>6863</td>
      <td>9188</td>
      <td>1993-07-28</td>
      <td>127080</td>
      <td>60</td>
      <td>2118.0</td>
      <td>A</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5325</td>
      <td>1843</td>
      <td>1993-08-03</td>
      <td>105804</td>
      <td>36</td>
      <td>2939.0</td>
      <td>A</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7240</td>
      <td>11013</td>
      <td>1993-09-06</td>
      <td>274740</td>
      <td>60</td>
      <td>4579.0</td>
      <td>A</td>
    </tr>
  </tbody>
</table>
</div>




```python
finished_loans = loan_data[loan_data['status'] == 'B']
finished_loans['due_percentage'] = 0.05  # 5% due percentage for finished loans
finished_loans['due_amount'] = finished_loans['amount'] * finished_loans['due_percentage']

# Display the result
print("Loans with finished contracts (status 'B'):")
print(finished_loans[['loan_id', 'amount', 'due_percentage', 'due_amount']])
```

    Loans with finished contracts (status 'B'):
         loan_id  amount  due_percentage  due_amount
    0       5314   96396            0.05      4819.8
    7       6111  174744            0.05      8737.2
    12      6228  464520            0.05     23226.0
    19      7097   75624            0.05      3781.2
    28      6650   49320            0.05      2466.0
    41      7066  215388            0.05     10769.4
    49      6316   76908            0.05      3845.4
    58      6210   87216            0.05      4360.8
    62      6112  174744            0.05      8737.2
    68      6232  276660            0.05     13833.0
    74      5126  208128            0.05     10406.4
    77      5395  299088            0.05     14954.4
    94      6594  189696            0.05      9484.8
    95      6738  230220            0.05     11511.0
    110     5176  192552            0.05      9627.6
    111     5269  164052            0.05      8202.6
    124     6244  270648            0.05     13532.4
    140     7241  168984            0.05      8449.2
    155     5352   68400            0.05      3420.0
    158     5045  187224            0.05      9361.2
    194     6342   60156            0.05      3007.8
    199     5805  137904            0.05      6895.2
    219     6027   61656            0.05      3082.8
    220     6303   72408            0.05      3620.4
    237     6501   30276            0.05      1513.8
    239     4961   30276            0.05      1513.8
    243     5892   66480            0.05      3324.0
    281     6865   29448            0.05      1472.4
    435     5856   51360            0.05      2568.0
    452     5338   57360            0.05      2868.0
    467     5643   94512            0.05      4725.6
    

    C:\Users\CB SUMANTH\AppData\Local\Temp\ipykernel_13792\3448368950.py:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      finished_loans['due_percentage'] = 0.05  # 5% due percentage for finished loans
    C:\Users\CB SUMANTH\AppData\Local\Temp\ipykernel_13792\3448368950.py:3: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      finished_loans['due_amount'] = finished_loans['amount'] * finished_loans['due_percentage']
    


```python
trans_dataaa=trans_df.copy()
```


```python
trans_dataaa.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>trans_id</th>
      <th>account_id</th>
      <th>date</th>
      <th>type</th>
      <th>operation</th>
      <th>amount</th>
      <th>balance</th>
      <th>k_symbol</th>
      <th>bank</th>
      <th>account</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>695247</td>
      <td>2378</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>700.0</td>
      <td>700.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>171812</td>
      <td>576</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>900.0</td>
      <td>900.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>207264</td>
      <td>704</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>1000.0</td>
      <td>1000.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1117247</td>
      <td>3818</td>
      <td>1993-01-01</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>600.0</td>
      <td>600.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>579373</td>
      <td>1972</td>
      <td>1993-01-02</td>
      <td>PRIJEM</td>
      <td>VKLAD</td>
      <td>400.0</td>
      <td>400.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
trans_dataaa['date'] = pd.to_datetime(trans_dataaa['date'])

# Extract month from date
trans_dataaa['month'] = trans_dataaa['date'].dt.month


monthly_summary = trans_dataaa.groupby('month').agg(total_transactions=('trans_id', 'count'), total_amount=('amount', 'sum'))

high_volume_months = monthly_summary[monthly_summary['total_transactions'] > 50]

# Calculate 2% charge for high-volume months
high_volume_months['charge'] = 0.02 * high_volume_months['total_amount']

# Display the result
print("Months with more than 50 transactions and their charge:")
print(high_volume_months)
```

    Months with more than 50 transactions and their charge:
           total_transactions  total_amount        charge
    month                                                
    1                  122214   544552851.6  1.089106e+07
    2                   70382   380721406.7  7.614428e+06
    3                   75364   442207242.5  8.844145e+06
    4                   76954   449583356.3  8.991667e+06
    5                   79931   478846447.8  9.576929e+06
    6                   88276   668725509.8  1.337451e+07
    7                   83791   491008930.8  9.820179e+06
    8                   86204   509006460.9  1.018013e+07
    9                   87955   522554280.8  1.045109e+07
    10                  90839   542445627.1  1.084891e+07
    11                  91890   543064201.4  1.086128e+07
    12                 102520   685077244.6  1.370154e+07
    

These are some financial introduction scheme that can generate the profit for banks.


```python

```

# Conclusion

In this python work book i generate python code for manipulate the data to better understanding and visualization to get better result based on the question.

Here the List of answer we generate the code and visualization.

A)Demographic profile across through client from various district.
B)Performance of bank over the years.
C)Accounts and types how differ from other.
D)Types of Cards and their results
E)Loan status info.
F)Expenses of Bank

List of answer to improve the bank profitability and performance.


```python

```
